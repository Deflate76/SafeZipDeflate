# NpncbDiagnostic

ZIP의 raw DEFLATE 스트림을 직접 분석해 NPNCB와 DBA 기반 메시지 은닉 흔적을 진단하는 C#/.NET 8 Windows 콘솔 프로그램입니다. 인수 없이 실행하면 `OpenFileDialog`로 ZIP 하나를 선택합니다.

## 주요 기능

- ZIP의 모든 Central Directory 엔트리 확인
- 모든 비암호화 DEFLATE(method 8) 엔트리 분석
- Stored, Fixed, Dynamic 물리적 블록 파싱
- LZ77 distance copy를 포함한 실제 출력 복호화
- uncompressed size와 CRC-32 검증
- NPNCB 개수와 각 DBA 시작 위치·비트 수·값 기록
- 여러 NPNCB의 DBA를 물리적 순서대로 연결
- LSB-first 바이트 복원
- `0x00` 종료자 기반 UTF-8 메시지 후보 탐지
- 다중 엔트리 전체 요약 및 텍스트 보고서 저장
- 콘솔 자동화용 종료 코드

## 실행

```powershell
dotnet build -c Release
dotnet run -c Release
```

명령행:

```powershell
NpncbDiagnostic.exe "archive.zip"
NpncbDiagnostic.exe "archive.zip" --details
NpncbDiagnostic.exe "archive.zip" --report "diagnostic.txt"
NpncbDiagnostic.exe "archive.zip" --details --report "diagnostic.txt"
```

옵션:

```text
--details          NPNCB별 물리적 블록 번호, DBA 위치, 값 출력
--report <path>    UTF-8 텍스트 보고서 저장
--help             도움말
```

종료 코드:

```text
0  CLEAN 또는 INFORMATIONAL
1  SUSPICIOUS 또는 WARNING
2  INCONCLUSIVE 또는 처리 오류
```

## 메시지 호환 형식

동봉된 `DbaMessageInserter`의 현재 형식과 호환됩니다.

```text
연결 DBA 비트: NPNCB #0 → NPNCB #1 → NPNCB #2 → ...
바이트 순서:   각 UTF-8 바이트의 bit 0 → bit 7 (LSB-first)
종료:          첫 0x00 바이트
```

예를 들어 DBA 연결 결과가 다음 바이트라면:

```text
48 65 6C 6C 6F 00 00 00 ...
```

메시지 후보는 `Hello`입니다.

현재 PoC에는 별도의 magic signature가 없습니다. 따라서 유효한 UTF-8과 종료자, 종료자 뒤 zero padding을 함께 사용해 신뢰도를 평가하지만, 이는 암호학적으로 확정적인 식별자가 아닙니다.

## 판정 원칙

### CLEAN

분석 가능한 DEFLATE 엔트리에 NPNCB가 없습니다.

### INFORMATIONAL

NPNCB는 있지만 DBA 비트가 모두 0입니다. 정상적인 empty Stored block 또는 flush 산출물일 수 있습니다.

### SUSPICIOUS

DBA에 0이 아닌 비트가 있으나 다음 중 하나입니다.

- 완전한 바이트가 부족함
- strict UTF-8이 아님
- 제어문자 비율이 높음
- 종료자가 없음
- 종료자 뒤에도 0이 아닌 비트가 있음

### WARNING

0이 아닌 DBA를 연결했을 때 다음을 모두 만족합니다.

- 비어 있지 않은 strict UTF-8 문자열
- 문자 가독성 비율 90% 이상
- `0x00` 종료자 존재
- 종료자 뒤 DBA 비트가 모두 0

### INCONCLUSIVE

암호화된 DEFLATE 엔트리, 크기 제한 초과, ZIP64, multi-disk, 손상된 ZIP/DEFLATE 구조 등으로 완전한 검사가 불가능합니다.

## 안전 제한

기본 `DiagnosticOptions`:

```csharp
MaximumEntries                  = 100_000
MaximumCompressedBytesPerEntry = 512 MiB
MaximumDecodedBytesPerEntry    = 1 GiB
MaximumPhysicalBlocksPerEntry  = 2_000_000
MaximumDbaBitsPerEntry         = 64 Mi bits
```

복호화 데이터 전체를 메모리에 보관하지 않습니다. 32 KiB DEFLATE 윈도와 CRC 상태만 유지합니다. 다만 raw compressed entry는 비트 단위 랜덤 접근을 위해 엔트리별로 메모리에 읽습니다.

## 지원 범위

지원:

- 표준 single-disk ZIP
- Central Directory 기반 데이터 위치·크기
- data descriptor 사용 엔트리
- DEFLATE method 8
- 여러 ZIP 엔트리

현재 예제에서 미지원:

- ZIP64
- multi-disk ZIP
- 암호화 엔트리
- 2 GiB보다 큰 단일 raw compressed entry
- DEFLATE 이외 압축 방식의 내부 블록 분석

미지원 엔트리는 숨기지 않고 보고서에 `INCONCLUSIVE` 또는 skip 사유로 표시합니다.

## 핵심 파일

```text
Program.cs                 파일 선택, CLI, 종료 코드, 보고서 저장
ZipArchiveAnalyzer.cs      전체 ZIP 엔트리 진단 및 최종 판정
ZipContainerReader.cs      EOCD/Central/Local Header와 raw data 추출
DeflateScanner.cs          블록 파싱, 실제 출력 복호화, NPNCB/DBA 수집
DeflateOutputTracker.cs    32 KiB 윈도, distance copy, CRC-32
DbaMessageDetector.cs      DBA 연결 바이트와 UTF-8 메시지 후보 분석
ReportFormatter.cs         사람이 읽을 수 있는 진단 보고서
```

## 주의

이 도구는 NPNCB DBA covert channel 진단용입니다. ZIP에 포함된 실행 파일, 매크로, 스크립트, 경로 탐색 항목, 압축 폭탄 등 다른 보안 위험을 종합 검사하는 백신이나 샌드박스가 아닙니다.
