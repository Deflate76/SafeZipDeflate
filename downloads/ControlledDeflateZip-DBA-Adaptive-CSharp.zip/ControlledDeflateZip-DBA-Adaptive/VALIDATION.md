# 검증 결과

## C# 빌드

전체 솔루션을 .NET 8 SDK로 Release 빌드했습니다.

```text
DbaMessageRestorer -> net8.0-windows/DbaMessageRestorer.dll
DbaMessageInserter -> net8.0-windows/DbaMessageInserter.dll
Build succeeded.
0 Warning(s)
0 Error(s)
```

## 실제 C# 왕복 시험

삽입기와 복원기의 핵심 소스 파일을 동일하게 참조하는 `net8.0` 시험 실행기를 별도로 빌드해 다음 순서를 실제 C# 코드로 실행했습니다.

1. `BuildAdaptivePlan`으로 Auto 데이터 블록과 NPNCB 계획 생성
2. Stored/Fixed/Dynamic 후보의 정확한 비트 수 계산
3. 선택된 블록과 NPNCB DBA 메시지를 포함한 ZIP 생성
4. 표준 `ZipArchive`로 압축 해제해 원본 바이트 비교
5. `ZipDbaMessageReader`로 raw DEFLATE 재파싱
6. 모든 NPNCB DBA를 연결해 메시지 복원
7. 각 Auto 블록의 실제 기록 비트 수가 세 후보의 최솟값인지 확인

결과:

```text
tiny    input=     11 compressed=    172 Stored= 0 Fixed= 1 Dynamic= 0 NPNCB=  32 DBA=  158 ROUNDTRIP_OK
repeat  input=  60000 compressed=    941 Stored= 0 Fixed= 0 Dynamic= 4 NPNCB= 128 DBA=  636 ROUNDTRIP_OK
text    input= 225000 compressed=   3704 Stored= 0 Fixed= 0 Dynamic=14 NPNCB= 448 DBA= 2242 ROUNDTRIP_OK
random  input=  50000 compressed=  50660 Stored= 4 Fixed= 0 Dynamic= 0 NPNCB= 128 DBA=  640 ROUNDTRIP_OK
mixed   input=  49152 compressed=  17016 Stored= 1 Fixed= 0 Dynamic= 2 NPNCB=  96 DBA=  477 ROUNDTRIP_OK
tail    input=  16395 compressed=  16721 Stored= 1 Fixed= 1 Dynamic= 0 NPNCB=  64 DBA=  318 ROUNDTRIP_OK
ALL_CSHARP_TESTS_PASSED
```

이 결과로 한 ZIP 안에서도 데이터 특성에 따라 Dynamic → Stored → Dynamic처럼 서로 다른 데이터 블록 형식이 선택되고, 작은 마지막 구간에서는 Fixed가 선택될 수 있음을 확인했습니다.

## 추가 포맷 검사

C# 구현과 같은 package-merge, Dynamic 헤더, 후보 비교 및 NPNCB 처리를 재현한 독립 기준 구현으로 다음도 검사했습니다.

- 길이 0~49,999바이트
- 데이터 유형 5종
- 데이터 블록 크기 256/1024/4096/16384
- 데이터 블록당 NPNCB 0/1/3/8개
- 총 80개 무작위 raw DEFLATE 왕복 시험

모든 스트림이 표준 zlib raw inflater에서 원본으로 복원됐고, 별도 DEFLATE 파서가 Dynamic/Fixed/Stored/NPNCB를 순회해 DBA payload를 동일하게 복원했습니다.
