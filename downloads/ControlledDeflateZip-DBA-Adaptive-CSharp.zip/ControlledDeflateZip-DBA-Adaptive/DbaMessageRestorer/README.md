# DbaMessageRestorer

ZIP의 첫 번째 DEFLATE 엔트리를 raw 비트 수준으로 읽고, 모든 0길이 Stored 블록(NPNCB)의 DBA 정렬 비트를 물리적 순서대로 연결해 UTF-8 메시지를 복원하는 독립 프로젝트입니다.

복원 로직은 이전 버전과 동일합니다. Stored, Fixed Huffman뿐 아니라 블록별 실제 빈도로 생성된 일반 Dynamic Huffman 헤더도 파싱하므로 적응형 `DbaMessageInserter` 결과를 처리할 수 있습니다.

## 실행

Windows에서 .NET 8 SDK를 설치한 뒤:

```powershell
dotnet build -c Release
dotnet run
```

인수 없이 실행하면 ZIP 선택 대화상자가 열립니다. 명령줄 경로도 지원합니다.

```powershell
dotnet run -- "C:\data\output.zip"
```

분석 후 메시지를 콘솔에 표시하고, 필요하면 복원된 바이트를 `.txt` 또는 `.bin` 파일로 저장합니다.

## 복원 방식

1. EOCD와 Central Directory를 읽어 첫 번째 DEFLATE(method 8) 엔트리의 raw 압축 바이트를 찾습니다.
2. BFINAL/BTYPE을 따라 Stored, Fixed Huffman, Dynamic Huffman 블록을 순회합니다.
3. Dynamic 블록에서는 HLIT, HDIST, HCLEN 및 code-length 반복 심볼 16/17/18을 파싱합니다.
4. `BTYPE=00`, `LEN=0`, `NLEN=0xFFFF`인 블록을 NPNCB로 판단합니다.
5. 각 NPNCB의 3비트 헤더 뒤에서 다음 바이트 경계까지의 DBA 비트를 수집합니다.
6. DBA를 물리적 순서대로 연결하고 8비트씩 LSB-first 바이트로 복원합니다.
7. 첫 `0x00`에서 메시지를 끝내고 strict UTF-8로 디코딩합니다.

## 포함 범위

이 프로젝트에는 ZIP/DEFLATE 읽기와 메시지 복원 코드만 있습니다. ZIP 생성 및 DBA 삽입 코드는 별도 `DbaMessageInserter` 프로젝트에 있습니다.

제한: 첫 번째 Central Directory 엔트리만 처리하며, ZIP64·분할 ZIP·암호화 엔트리는 지원하지 않습니다.
