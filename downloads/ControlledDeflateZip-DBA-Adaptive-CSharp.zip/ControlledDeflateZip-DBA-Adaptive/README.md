# ControlledDeflateZip DBA — 적응형 블록 선택 / 분리 프로젝트

이 솔루션은 NPNCB(길이 0인 DEFLATE Stored block)의 바이트 정렬 영역(DBA)에 UTF-8 메시지를 기록하는 삽입기와 복원기를 서로 독립된 두 프로젝트로 제공합니다.

이번 버전의 삽입기는 실데이터 블록을 `Dynamic → Fixed → Stored` 순서로 강제하지 않습니다. 각 데이터 구간에서 Stored, Fixed, Dynamic 후보를 실제로 분석하고 가장 작은 DEFLATE 블록 형식을 선택합니다. NPNCB 삽입과 DBA 메시지 형식은 이전 버전과 동일합니다.

## 프로젝트 구성

### `DbaMessageInserter`

1. 입력 메시지를 UTF-8 바이트 배열로 변환
2. 입력 파일을 `DataBlockSize` 단위의 Auto 데이터 구간으로 분할
3. 각 구간의 Stored/Fixed/Dynamic 정확한 비트 비용 계산
4. 가장 작은 데이터 블록 형식 선택
5. 각 데이터 블록 뒤에 사용자가 지정한 개수의 NPNCB 삽입
6. 모든 NPNCB의 DBA 용량 계산
7. 메시지 비트를 DBA 순서대로 LSB-first 기록
8. 단일 엔트리 ZIP 작성
9. 일반 `ZipArchive`로 원본 파일 복원 검증

Dynamic 후보는 블록별 실제 LZ77 토큰 빈도에서 길이 제한 Huffman 트리를 생성합니다.

이 프로젝트에는 사용자 정의 DBA 추출기가 들어 있지 않습니다.

### `DbaMessageRestorer`

1. ZIP central directory와 local header에서 첫 번째 DEFLATE 엔트리 추출
2. raw DEFLATE의 Stored, Fixed, Dynamic 블록을 물리적 순서대로 파싱
3. `LEN=0x0000`, `NLEN=0xFFFF`인 Stored block을 NPNCB로 판별
4. 각 NPNCB의 3비트 헤더 뒤 DBA 비트 수집
5. 모든 DBA 비트를 연결하고 LSB-first 바이트로 복원
6. 첫 `0x00` 이전 데이터를 strict UTF-8 메시지로 출력
7. 선택적으로 복원 데이터를 텍스트 또는 바이너리 파일로 저장

복원기는 일반적인 Dynamic Huffman 헤더를 파싱하므로 새 적응형 삽입기가 생성한 블록도 그대로 처리합니다. 이 프로젝트에는 ZIP 생성기나 DEFLATE 인코더가 들어 있지 않습니다.

## 메시지 형식

```text
UTF-8 메시지 바이트 [선택적 0x00 종료자]
```

각 바이트는 bit 0부터 bit 7까지 기록합니다. DBA가 바뀌어도 메시지 비트 인덱스는 이어집니다.

DBA 총 용량이 메시지보다 작으면 UTF-8 문자가 깨지지 않는 가장 긴 접두부만 저장합니다. 완전한 바이트 하나가 남으면 `0x00` 종료자를 추가합니다. 메시지 본문에서 U+0000은 종료자로 예약됩니다.

## 빌드

Windows와 .NET 8 SDK가 필요합니다.

```text
ControlledDeflateZip-DBA-Adaptive.sln
```

```powershell
dotnet build .\ControlledDeflateZip-DBA-Adaptive.sln -c Release

dotnet run --project .\DbaMessageInserter\DbaMessageInserter.csproj
dotnet run --project .\DbaMessageRestorer\DbaMessageRestorer.csproj
```

## 핵심 코드 위치

```text
DbaMessageInserter/RawDeflateEncoder.cs
  AnalyzeAdaptiveBlock(...)
  DynamicBlockPlan.Build(...)
  WriteNpncbBlock(...)

DbaMessageInserter/LengthLimitedHuffmanBuilder.cs
  Build(...)

DbaMessageRestorer/ZipDbaMessageReader.cs
  DeflateDbaScanner.ReadStoredBlock(...)
```

## 제한 사항

- classic ZIP 단일 엔트리 생성
- 복원기는 첫 번째 central-directory 엔트리만 분석
- ZIP64, 분할 ZIP, 암호화 엔트리 미지원
- compression method 8(DEFLATE) 전용
- 일반적인 길이 0 Stored block도 구조상 NPNCB로 수집
- 블록 경계는 고정된 `DataBlockSize` 단위이며, 경계 자체를 전역 최적화하지 않음
- LZ77은 읽기 쉬운 greedy hash-chain 구현이며 production zlib의 lazy/optimal parsing과 동일하지 않음

포맷 연구, 상호운용성 시험 및 방어적 분석 환경에서 사용하십시오.
